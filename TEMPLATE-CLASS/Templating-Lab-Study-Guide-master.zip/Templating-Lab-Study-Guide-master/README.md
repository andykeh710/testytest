
# TEMPLATING LINKS

[Handlebars](https://handlebarsjs.com/)

[Embedded JavaScript Syntax](https://ejs.co)

[Pug](https://pugjs.org/api/getting-started.html)

[When NOT to use Handlebars](https://handlebarsjs.com/installation/when-to-use-handlebars.html)

# LINKS OTHER STUDENTS FOUND USEFUL

[Faith's Super Useful HBS YouTube Tutorial (30 min)](https://www.youtube.com/watch?v=4HuAnM6b2d8)

[Linda's handy HBS Guide](https://medium.com/@thejasonfile/creating-templates-with-handlebars-js-15c2fa45859)

[Ken's Stupendous HBS Article](https://medium.com/@BuildMySite1/javascript-templating-what-is-templating-7ff49d97db6b)
