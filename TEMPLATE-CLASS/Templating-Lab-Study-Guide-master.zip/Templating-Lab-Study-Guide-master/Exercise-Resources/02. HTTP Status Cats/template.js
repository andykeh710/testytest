(() => {
     renderCatTemplate();

     function renderCatTemplate() {
         // TODO: Render cat template and attach events
     }
 
})
