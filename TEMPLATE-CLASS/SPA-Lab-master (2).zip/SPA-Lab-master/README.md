# SPA Routing Lab

Clone the repo and run "npm install". Then open your browser to port 2001 to get started.
